﻿namespace Library.Domain
{
    internal class ViewAllBooks
    {
        private Library library;
        private Library library1;

        public ViewAllBooks(Library library)
        {
            this.library = library;
        }

        internal void Execute()
        {
            throw new NotImplementedException();
        }
    }
}