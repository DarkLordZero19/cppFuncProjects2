﻿namespace Library.Domain
{
    internal class AddBook
    {
        private Library library;

        public AddBook(Library library) => this.library = library;

        internal void Execute()
        {
            throw new NotImplementedException();
        }
    }
}