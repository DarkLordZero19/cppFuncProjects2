﻿namespace Library.Domain
{
    internal class ReturnBook
    {
        private Library library;
        private Library library1;

        public ReturnBook(Library library)
        {
            this.library = library;
        }

        internal void Execute()
        {
            throw new NotImplementedException();
        }
    }
}