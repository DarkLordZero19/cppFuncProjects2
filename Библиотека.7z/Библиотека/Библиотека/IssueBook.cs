﻿namespace Library.Domain
{
    internal class IssueBook
    {
        private Library library;
        private Library library1;

        public IssueBook(Library library)
        {
            this.library = library;
        }

        internal void Execute()
        {
            throw new NotImplementedException();
        }
    }
}