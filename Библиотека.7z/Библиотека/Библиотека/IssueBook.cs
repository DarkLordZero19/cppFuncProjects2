﻿namespace Library.Domain
{
    internal class IssueBook
    {
        private Library library;

        public IssueBook(Library library)
        {
            this.library = library;
        }

        internal void Execute()
        {
            throw new NotImplementedException();
        }
    }
}