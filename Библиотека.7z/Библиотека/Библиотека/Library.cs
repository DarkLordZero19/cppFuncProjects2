﻿namespace Library.Domain
{
    internal class Library
    {
        internal void SearchBooks(string? searchTerm)
        {
            throw new NotImplementedException();
        }

        internal void ViewAllUsers()
        {
            throw new NotImplementedException();
        }
    }
}