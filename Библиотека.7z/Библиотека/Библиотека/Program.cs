﻿using Библиотека.Domain.Models;

namespace Library.Domain
{
    public class Program
    {
        private static Library library;
        private static Library GetLibrary()
        {
            return library;
        }

        static void Main(string[] args)
        {
            Library library = new Library();
            while (true)
            {
                Console.WriteLine("\nLibrary Management System");
                Console.WriteLine("1. Add a new book");
                Console.WriteLine("2. Register a new user");
                Console.WriteLine("3. Issue a book");
                Console.WriteLine("4. Return a book");
                Console.WriteLine("5. View all books");
                Console.WriteLine("6. View all users");
                Console.WriteLine("7. Search for a book");
                Console.WriteLine("8. Exit");
                Console.Write("Choose an option: ");

                string choice = Console.ReadLine();

                Book book = new Book();
                switch (choice)
                {
                    case "1":
                        var addBook = new AddBook(library: library);
                        addBook.Execute();
                        break;

                    case "2":
                        var registerUser = new RegisterUser(library);
                        registerUser.Execute();
                        break;

                    case "3":
                        var issueBook = new IssueBook(library);
                        issueBook.Execute();
                        break;

                    case "4":
                        var returnBook = new ReturnBook(library);
                        returnBook.Execute();
                        break;

                    case "5":
                        var viewAllBooks = new ViewAllBooks(library);
                        viewAllBooks.Execute();
                        break;

                    case "6":
                        library.ViewAllUsers();
                        break;

                    case "7":
                        Console.Write("Enter search term (title or author): ");
                        string searchTerm = Console.ReadLine();

                        library.SearchBooks(searchTerm);
                        break;

                    case "8":
                        return;

                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }
    }
}