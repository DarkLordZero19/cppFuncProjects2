﻿namespace Library.Domain
{
    internal class RegisterUser
    {
        private Library library;

        public RegisterUser(Library library)
        {
            this.library = library;
        }

        internal void Execute()
        {
            throw new NotImplementedException();
        }
    }
}