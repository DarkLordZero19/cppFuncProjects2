﻿namespace Библиотека.Domain.Models
{
    public class IssueBook
    {
        private Library library;

        public IssueBook(Library library)
        {
            this.library = library;
        }

        public void Execute()
        {
            Console.Write("Enter user ID: ");
            if (!int.TryParse(Console.ReadLine(), out int userId))
            {
                Console.WriteLine("Invalid ID. Please try again.");
                return;
            }

            Console.Write("Enter ISBN of the book: ");
            string isbn = Console.ReadLine();

            library.IssueBook(userId, isbn);
        }
    }
}
