﻿namespace Библиотека.Domain.Models
{
    public class AddBook
    {
        private Library library;
        private global::Library library1;

        public AddBook(Library library)
        {
            this.library = library;
        }

        public AddBook(global::Library library1)
        {
            this.library1 = library1;
        }

        public void Execute()
        {
            Console.Write("Enter title: ");
            string title = Console.ReadLine();

            Console.Write("Enter author: ");
            string author = Console.ReadLine();

            Console.Write("Enter year: ");
            if (!int.TryParse(Console.ReadLine(), out int year))
            {
                Console.WriteLine("Invalid year. Please try again.");
                return;
            }

            Console.Write("Enter ISBN: ");
            string isbn = Console.ReadLine();

            library.AddBook(title, author, year, isbn);
        }
    }
}
