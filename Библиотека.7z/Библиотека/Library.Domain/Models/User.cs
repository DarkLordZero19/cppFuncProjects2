﻿namespace Библиотека.Domain.Models
{
    public class User
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public List<(Book, DateTime)> BorrowedBooks { get; set; } = new List<(Book, DateTime)>();

        public User(int id, string firstName, string lastName)
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
        }

        public override string ToString()
        {
            return $"{FirstName} {LastName} (ID: {Id})";
        }
    }
}
