﻿namespace Библиотека.Domain.Models
{
    public class Library
    {
        private List<Book> books = new List<Book>();
        private List<User> users = new List<User>();

        public void AddBook(string title, string author, int year, string isbn)
        {
            books.Add(new Book(title, author, year, isbn));
            Console.WriteLine("Book added successfully.");
        }

        public void RegisterUser(int id, string firstName, string lastName)
        {
            users.Add(new User(id, firstName, lastName));
            Console.WriteLine("User registered successfully.");
        }

        public void ViewAllUsers()
        {
            foreach (var user in users)
            {
                Console.WriteLine(user);
            }
        }

        public void IssueBook(int userId, string isbn)
        {
            var user = users.FirstOrDefault(u => u.Id == userId);
            var book = books.FirstOrDefault(b => b.ISBN == isbn && b.IsAvailable);

            if (user == null)
            {
                Console.WriteLine("User not found.");
                return;
            }

            if (book == null)
            {
                Console.WriteLine("Book not available.");
                return;
            }

            user.BorrowedBooks.Add((book, DateTime.Now));
            book.IsAvailable = false;
            Console.WriteLine($"Book issued to {user.FirstName} {user.LastName} on {DateTime.Now}.");
        }

        public void ReturnBook(int userId, string isbn)
        {
            var user = users.FirstOrDefault(u => u.Id == userId);
            var borrowedBook = user?.BorrowedBooks.FirstOrDefault(b => b.Item1.ISBN == isbn);

            if (borrowedBook == null)
            {
                Console.WriteLine("Book not found in user's borrowed books.");
                return;
            }

            user.BorrowedBooks.Remove(borrowedBook.Value);
            borrowedBook.Value.Item1.IsAvailable = true;
            Console.WriteLine($"Book returned on {DateTime.Now}.");
        }

        public void ViewAllBooks()
        {
            foreach (var book in books)
            {
                Console.WriteLine(book);
            }
        }

        public void SearchBooks(string searchTerm)
        {
            var results = books.Where(b => b.Title.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                                           b.Author.Contains(searchTerm, StringComparison.OrdinalIgnoreCase));
            foreach (var book in results)
            {
                Console.WriteLine(book);
            }
        }
    }
}
