﻿namespace Library.Domain
{
    public class Domain
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public int Year { get; set; }
        public string ISBN { get; set; }
        public bool IsAvailable { get; set; } = true;

        public Domain(string title, string author, int year, string isbn)
        {
            Title = title;
            Author = author;
            Year = year;
            ISBN = isbn;
        }

        public override string ToString()
        {
            return $"{Title} by {Author}, {Year} (ISBN: {ISBN}) - {(IsAvailable ? "Available" : "Checked out")}";
        }
    }
    public class Book
    {

    }
    public class User
    {

    }
    public class Library
    {
        public override bool Equals(object? obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string? ToString()
        {
            return base.ToString();
        }

        public void SearchBooks(string? searchTerm)
        {
            throw new NotImplementedException();
        }

        public void ViewAllUsers()
        {
            throw new NotImplementedException();
        }
    }
    public class ViewAllBooks
    {
        private Library library;

        public ViewAllBooks(Library library)
        {
            this.library = library;
        }

        public void Execute()
        {
            throw new NotImplementedException();
        }
    }
    public class AddBook
    {
        private Library library;

        public AddBook(Library library)
        {
            this.library = library;
        }

        public void Execute()
        {
            throw new NotImplementedException();
        }
    }
    public class ReturnBook
    {
        private Library library;

        public ReturnBook(Library library)
        {
            this.library = library;
        }

        public void Execute()
        {
            throw new NotImplementedException();
        }
    }

    public class RegisterUser
    {
        private Library library;

        public RegisterUser(Library library)
        {
            this.library = library;
        }

        public void Execute()
        {
            throw new NotImplementedException();
        }
    }

    internal class IssueBook
    {
        private Library library;

        public IssueBook(Library library)
        {
            this.library = library;
        }

        internal void Execute()
        {
            throw new NotImplementedException();
        }
    }
}