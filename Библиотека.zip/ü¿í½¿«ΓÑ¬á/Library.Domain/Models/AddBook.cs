﻿namespace Библиотека.Domain.Models
{
    public class AddBook
    {
        private Library library;

        public AddBook(Library library)
        {
            this.library = library;
        }

        public void Execute()
        {
            Console.Write("Enter title: ");
            string title = Console.ReadLine();

            Console.Write("Enter author: ");
            string author = Console.ReadLine();

            Console.Write("Enter year: ");
            if (!int.TryParse(Console.ReadLine(), out int year))
            {
                Console.WriteLine("Invalid year. Please try again.");
                return;
            }

            Console.Write("Enter ISBN: ");
            string isbn = Console.ReadLine();

            library.AddBook(title, author, year, isbn);
        }
    }
}
