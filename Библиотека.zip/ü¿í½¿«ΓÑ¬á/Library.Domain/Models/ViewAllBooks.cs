﻿namespace Библиотека.Domain.Models
{
    public class ViewAllBooks
    {
        private Library library;
        private global::Library library1;

        public ViewAllBooks(Library library)
        {
            this.library = library;
        }

        public ViewAllBooks(global::Library library1)
        {
            this.library1 = library1;
        }

        public void Execute()
        {
            library.ViewAllBooks();
        }
    }
}
