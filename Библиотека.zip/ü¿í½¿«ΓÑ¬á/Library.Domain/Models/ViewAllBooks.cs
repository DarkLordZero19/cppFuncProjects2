﻿namespace Библиотека.Domain.Models
{
    public class ViewAllBooks
    {
        private Library library;

        public ViewAllBooks(Library library)
        {
            this.library = library;
        }

        public void Execute()
        {
            library.ViewAllBooks();
        }
    }
}
