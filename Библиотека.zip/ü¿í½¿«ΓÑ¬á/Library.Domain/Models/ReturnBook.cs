﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Библиотека.Domain.Models
{
    public class ReturnBook
    {
        private Library library;
        private global::Library library1;

        public ReturnBook(Library library)
        {
            this.library = library;
        }

        public ReturnBook(global::Library library1)
        {
            this.library1 = library1;
        }

        public void Execute()
        {
            Console.Write("Enter user ID: ");
            if (!int.TryParse(Console.ReadLine(), out int userId))
            {
                Console.WriteLine("Invalid ID. Please try again.");
                return;
            }

            Console.Write("Enter ISBN of the book: ");
            string isbn = Console.ReadLine();

            library.ReturnBook(userId, isbn);
        }
    }
}
