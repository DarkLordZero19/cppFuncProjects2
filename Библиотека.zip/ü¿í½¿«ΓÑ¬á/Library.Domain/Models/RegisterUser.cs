﻿namespace Библиотека.Domain.Models
{
    public class RegisterUser
    {
        private Library library;
        private global::Library library1;

        public RegisterUser(Library library)
        {
            this.library = library;
        }

        public RegisterUser(global::Library library1)
        {
            this.library1 = library1;
        }

        public void Execute()
        {
            Console.Write("Enter user ID: ");
            if (!int.TryParse(Console.ReadLine(), out int userId))
            {
                Console.WriteLine("Invalid ID. Please try again.");
                return;
            }

            Console.Write("Enter first name: ");
            string firstName = Console.ReadLine();

            Console.Write("Enter last name: ");
            string lastName = Console.ReadLine();

            library.RegisterUser(userId, firstName, lastName);
        }
    }
}
