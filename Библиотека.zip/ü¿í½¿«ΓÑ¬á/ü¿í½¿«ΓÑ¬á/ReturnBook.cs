﻿namespace Library.Domain
{
    internal class ReturnBook
    {
        private Library library;

        public ReturnBook(Library library)
        {
            this.library = library;
        }

        internal void Execute()
        {
            throw new NotImplementedException();
        }
    }
}