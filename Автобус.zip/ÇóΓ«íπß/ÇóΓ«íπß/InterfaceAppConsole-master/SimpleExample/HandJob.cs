﻿namespace InterfaceAppConsole
{
    public class HandJob : IJob
    {
public void DoJob()
{
Console.WriteLine("Hand job");
}
    }
}
