﻿namespace InterfaceAppConsole
{
    public class FoodJob : IJob
    {
public void DoJob()
{
    Console.WriteLine("Food job");
}
    }
}
