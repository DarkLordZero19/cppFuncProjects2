﻿namespace InterfaceAppConsole
{
public interface IJob
    {
public void DoJob();
    }
}
