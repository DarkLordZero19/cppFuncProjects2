﻿namespace InterfaceAppConsole.Navigator
{
    internal interface IGetTime
    {
        public int GetTime(double kilometers);
    }
}
