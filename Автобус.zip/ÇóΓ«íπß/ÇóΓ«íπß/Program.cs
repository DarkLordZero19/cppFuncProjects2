﻿using System;
namespace InterfaceAppConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите время в часах:");
            double timeInHours = Convert.ToDouble(Console.ReadLine());

            double speed = 40.0;
            double distance = CalculateDistance(speed, timeInHours);

            Console.WriteLine($"Расстояние: {distance} км");
        }

        static double CalculateDistance(double speed, double time)
        {
            return speed * time;
        }
    }
}
