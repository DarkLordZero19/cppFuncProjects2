﻿using Третий_урок.domain.Models;

Lion banifacity = new Lion();
banifacity.MakeSound();
banifacity.Eat();
banifacity.Sleep();

Elephant Twiiling = new Elephant();
Twiiling.MakeSound();
Twiiling.Eat();
Twiiling.Sleep();

Monkey Rose = new Monkey();
Rose.MakeSound();
Rose.Eat();
Rose.Sleep();