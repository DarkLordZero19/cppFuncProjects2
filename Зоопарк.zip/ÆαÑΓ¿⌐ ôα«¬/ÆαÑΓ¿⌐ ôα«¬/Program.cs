﻿using Третий_урок.domain.Models;

Lion simba = new Lion("Simba", 18, Species.Mammal, 2);
Elephant dambo = new Elephant("Dambo", 23, Species.Mammal, 2);
Lion banifac = new Lion("banifac", 23, Species.Mammal, -1);
Monkey makaka = new Monkey("Makaka", 12, Species.Mammal, 2);
Eagle knabib = new Eagle("Knabib", 35, Species.Birds, 3);
Crocodile blisk = new Crocodile("Blisk", 44, Species.Reptiles, 1);

// Lion : Animal
// Elefant : Animal
// Monket : Animal
// Crocodile : Animal
simba.Sleep();
dambo.Sleep();

Console.WriteLine(simba.PrideSize);
simba.PrideSize();

Console.WriteLine(simba.MakeSound);
dambo.MakeSound();
Zoo rostovzoo = new Zoo();
rostovzoo.addAnimal(dambo);
rostovzoo.addAnimal(simba);
rostovzoo.addAnimal(makaka);
rostovzoo.addAnimal(knabib);
rostovzoo.addAnimal(blisk);

rostovzoo.FeedAll();
List<Animal> searchResult = new List<Animal>(rostovzoo.SearchAnimal(Species.Mammal));
foreach (var item in searchResult)
{
    Console.WriteLine(item);
}


