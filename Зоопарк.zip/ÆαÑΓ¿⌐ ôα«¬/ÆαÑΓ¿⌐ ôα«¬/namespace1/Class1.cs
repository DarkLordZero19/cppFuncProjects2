﻿namespace namespace1
{
    internal class Class1
    {
        public Class1()
        {
        }

        internal void Print()
        {
            throw new NotImplementedException();
        }
    }
}

namespace namespace2
{
    internal class Class1
    {
    }
}