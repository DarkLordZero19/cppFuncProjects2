﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Третий_урок.domain.Models
{
    public abstract class Animal
    {
        public string Name { get; set; }   
        public int Age { get; set; }
        public string Species { get; set; }
        public int MyProperty { get; set; }
        public void Eat() => Console.WriteLine($"Меня зовут {Name}, я сейчас кушаю!");
        public void Sleep()
        {
            Console.WriteLine("Zzzz...");
        }
        public abstract void MakeSound();
    }
}
