﻿namespace Третий_урок.domain.Models
{
    public abstract class Animal
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public Species Species { get; set; }
        public int MyProperty { get; set; }
        protected Animal(string name, int age, Species species, int myProperty)
        {
            if (name.Length < 3)
            {
                
            }
            Name = name;
            Age = age;
            Species = species;
            MyProperty = myProperty;
        }
        public void Eat()
        {
            Console.WriteLine($"Меня зовут {Name}, Я кушаю");
        }
        public void Sleep()
        {
            Console.WriteLine("Я сплю по 12 часов, Zzzz...");
        }
        public abstract void MakeSound();
    }
}
