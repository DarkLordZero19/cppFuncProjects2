﻿using System;

namespace Третий_урок.domain.Models
{
    namespace namespace1
    {
        public class Namespace1
        {
            public void print()
            {
                Console.WriteLine("Привет 1");
            }
        }
    }
}
