﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Третий_урок.domain.Models
{
    public class Elephant : Animal
    {
        public string trunkLength { get; set; }
        public override void MakeSound()
        {
            Console.WriteLine("Я слон, приогромный!!!");
        }
        public void TrunkLength()
        {
            Console.WriteLine("ВУУУУУУУУУУ!");
        }
    }
}
