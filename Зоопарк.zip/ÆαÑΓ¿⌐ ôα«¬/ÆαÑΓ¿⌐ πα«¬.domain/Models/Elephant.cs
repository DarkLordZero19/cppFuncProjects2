﻿namespace Третий_урок.domain.Models
{
    public class Elephant : Animal
    {
        public Elephant(string name, int age, Species species, int myProperty) : base(name, age, species, myProperty)
        {
            
        }
        public string trunkLength { get; set; }
        public override void MakeSound()
        {
            Console.WriteLine("Я слон, УУУУУУ!!!");
        }
    }
}
