﻿namespace Третий_урок.domain.Models
{
    public class Zoo
    {
        private List<Animal> _animals = new List<Animal>();
        private const int MaxAnimals = 100;

        public Exception Exception { get; private set; }

        public void addAnimal(Animal animal)
        {
            if (_animals.Count() < 100)
            {
                _animals.Add(animal);
            }
            else
            {
                throw new Exception("Zoo site is full!");
            }
        }

        public void FeedAll()
        {
            foreach (var item in _animals)
            {
                item.Eat();
            }
        }

        public void addAnimal(Elephant dambo, Lion simba, Monkey makaka)
        {
            
        }

        public void addAnimal(Monkey makaka)
        {
            
        }

        public void addAnimal(Lion simba)
        {
            
        }

        public void addAnimal(Elephant dambo)
        {
            
        }
        public void addAnimal(Eagle knabib)
        {

        }

        public void addAnimal(Crocodile bisik)
        {

        }
        public void MakeSound()
        {
            foreach (var item in _animals)
            {
                item.MakeSound();
            }
        }
        public void ShowAllInfo()
        {
            foreach(var animal in _animals)
            {
                Console.WriteLine(animal.Age);
                Console.WriteLine(animal.Name);
                Console.WriteLine(animal.Species);
            }
        }
        public List<Animal> SearchAnimal(Species species)
        {
            List<Animal> result = new List<Animal>();

            foreach(var animal in _animals)
            {
                if(species == animal.Species)
                {
                    result.Add(animal);
                }
            }
            if (result.Count() == 0){
                throw Exception = new Exception("Животных такого вида в зоопарке не существует");
            }
        }
    }
}
