﻿namespace Третий_урок.domain.Models
{
    public class Monkey : Animal
    {
        public Monkey(string name, int age, Species species, int myProperty) : base(name, age, species, myProperty)
        {

        }

        public int jumper{ get; set; }
        public override void MakeSound()
        {
            Console.WriteLine("Я монки, чисто угага!");
        }
        public void Jumper()
        {
            Console.WriteLine("УГАГАГА!");
        }
    }
}
