﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Третий_урок.domain.Models
{
    public class Lion : Animal
    {
        public string prideSize { get; set; }
        public override void MakeSound()
        {
            Console.WriteLine("Я лев, чисто тигр!");
        }
        public void PrideSize()
        {
            Console.WriteLine("АРГХ!");
        }
    }
}
