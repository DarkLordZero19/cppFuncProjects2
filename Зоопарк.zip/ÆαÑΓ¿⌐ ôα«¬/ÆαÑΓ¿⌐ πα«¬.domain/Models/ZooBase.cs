﻿namespace Третий_урок.domain.Models
{
    public class ZooBase
    {
        public List<Animal> SearchAnimal(Species species)
        {
            List<Animal> result = new List<Animal>();

            foreach (var animal in _animals)
            {
                if (species == animal.Species)
                {
                    result.Add(animal);
                }
            }
            if (result.Count() == 0)
            {
                throw Exception = new Exception("Животных такого вида в зоопарке не существует");
            }
        }
    }
}