﻿namespace Третий_урок.domain.Models
{
    public enum Species
    {
        Mammal, //Млекопитающий
        Birds, //
        Reptiles //
    }
}
