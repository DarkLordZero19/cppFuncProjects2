﻿namespace Третий_урок.domain.Models
{
    public class Eagle : Animal
    {
        public Eagle(string name, int age, Species species, int myProperty) : base(name, age, species, myProperty)
        {
        }
        public override void MakeSound()
        {
            Console.WriteLine("Я орел, чисто вуаааа!");
        }
    }
}
