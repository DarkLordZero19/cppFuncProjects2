﻿namespace Третий_урок.domain.Models
{
    public class Lion : Animal
    {
        private int _prideSize;
        public Lion(string name, int age, Species species, int myProperty) : base(name, age, species, myProperty)
        {
            _prideSize = prideSize;
        }
        public int prideSize { get; set; }
        public override void MakeSound()
        {
            Console.WriteLine("Я лев, чисто тигр!");
        }
        public void PrideSize()
        {
            Console.WriteLine("АРГХ!");
        }
    }
}
