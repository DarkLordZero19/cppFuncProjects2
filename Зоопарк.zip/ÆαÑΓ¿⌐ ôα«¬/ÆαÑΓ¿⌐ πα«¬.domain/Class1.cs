﻿namespace Третий_урок.Domain
{
    public class Class1
    {

    }
}